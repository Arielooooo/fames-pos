const http = require('http');
const fs = require('fs');
const path = require('path');
const WebSocket = require('ws');

const PORT = process.env.PORT || 3000;

// Estado compartido
let estado = {
  orders: {}, cocina: [], domicilios: [], salesLog: [],
  salesByProduct: {}, cobroNum: 0, comNum: 0, domNum: 0,
  turnoActivo: null, historialTurnos: []
};

// Servidor HTTP
const server = http.createServer((req, res) => {
  let filePath = '';
  const url = req.url.split('?')[0];

  if (url === '/' || url === '/pos') {
    filePath = path.join(__dirname, 'FAMES_PuntoDeVenta.html');
  } else if (url === '/pedidos') {
    filePath = path.join(__dirname, 'FAMES_Pedidos.html');
  } else if (url === '/repartidor') {
    filePath = path.join(__dirname, 'FAMES_Repartidor.html');
  } else if (url === '/api/estado') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(estado));
    return;
  } else if (url === '/api/pedido-online' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', () => {
      try {
        const pedido = JSON.parse(body);
        estado.domNum = (estado.domNum || 0) + 1;
        pedido.id = estado.domNum;
        pedido.label = 'DOM-' + estado.domNum;
        pedido.estado = 'pendiente';
        pedido.origen = 'online';
        estado.domicilios = estado.domicilios || [];
        estado.domicilios.push(pedido);
        // Notificar a todos los clientes conectados
        wss.clients.forEach(client => {
          if (client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify({ tipo: 'nuevo_pedido_online', data: pedido }));
            client.send(JSON.stringify({ tipo: 'estado', data: estado }));
          }
        });
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: true, id: pedido.label }));
      } catch(e) {
        res.writeHead(400); res.end('Error');
      }
    });
    return;
  } else {
    res.writeHead(404); res.end('No encontrado');
    return;
  }

  fs.readFile(filePath, (err, data) => {
    if (err) { res.writeHead(404); res.end('Archivo no encontrado'); return; }
    const ext = path.extname(filePath);
    const mime = ext === '.html' ? 'text/html' : 'text/plain';
    res.writeHead(200, { 'Content-Type': mime + '; charset=utf-8' });
    res.end(data);
  });
});

// WebSocket
const wss = new WebSocket.Server({ server });

wss.on('connection', (ws) => {
  // Enviar estado actual al conectarse
  ws.send(JSON.stringify({ tipo: 'estado', data: estado }));

  ws.on('message', (msg) => {
    try {
      const data = JSON.parse(msg);
      if (data.tipo === 'actualizar') {
        estado = Object.assign(estado, data.data);
        // Broadcast a todos los demás
        wss.clients.forEach(client => {
          if (client !== ws && client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify({ tipo: 'estado', data: estado }));
          }
        });
      }
    } catch(e) {}
  });

  ws.on('error', () => {});
});

server.listen(PORT, () => {
  console.log('FAMES POS corriendo en puerto ' + PORT);
});
